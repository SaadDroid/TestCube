@Override
    public String getName() {
        return "PLANNER_OBJECT_EDITOR";
    }
