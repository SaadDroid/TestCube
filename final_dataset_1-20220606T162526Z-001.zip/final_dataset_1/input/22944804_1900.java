public static AuthTargetMappingBuilder builder() {
        return new AuthTargetMappingBuilder();
    }
