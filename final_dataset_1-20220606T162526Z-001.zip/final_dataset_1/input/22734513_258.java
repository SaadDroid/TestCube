@Override
  public Map<String, String> getBaseModuleIdsMapping() {
    return Collections.unmodifiableMap( this.baseModuleIdsMappings );
  }
