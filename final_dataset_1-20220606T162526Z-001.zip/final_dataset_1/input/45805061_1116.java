public static double square(final double x) {
    return x * x;
  }
