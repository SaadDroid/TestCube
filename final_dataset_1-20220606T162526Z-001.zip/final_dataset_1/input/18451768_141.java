@Override public Observable<Geofence> requestGeofences(RxLostApiClient client,
      GeofencingRequest geofencingRequest) {
    throw new RuntimeException("Sorry, not yet implemented");
  }
