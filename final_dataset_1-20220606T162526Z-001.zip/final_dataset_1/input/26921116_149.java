public LU lu() {
        return lu(false);
    }
