public String getAliasName()
   {
      return _aliasName;
   }
