public void setQualifier(Expression qualifier) {
		this.qualifier = qualifier;
	}
