@Override
    public Byte getByte()
    {
        return value.byteValue();
    }
