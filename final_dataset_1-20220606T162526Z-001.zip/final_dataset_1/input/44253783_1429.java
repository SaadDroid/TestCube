public void setPoolFactory(JdbcPoolFactory f) {
    this.poolFactory = f;
  }
