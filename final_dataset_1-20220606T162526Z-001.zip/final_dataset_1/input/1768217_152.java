public CursoredList<Long> getFollowerIds() {
		return getFollowerIdsInCursor(-1);
	}
