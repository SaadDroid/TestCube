int modifier(int input) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }
