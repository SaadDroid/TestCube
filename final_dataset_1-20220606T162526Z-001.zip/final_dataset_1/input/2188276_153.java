public String getFileSpecifiedDir()
   {
      return _fileSpecifiedDir;
   }
