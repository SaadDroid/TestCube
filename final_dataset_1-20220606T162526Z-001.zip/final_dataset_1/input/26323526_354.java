@Override
  public void setGraphIds(GradoopIdSet graphIds) {
    this.graphIds = graphIds;
  }
