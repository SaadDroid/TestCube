public Settings setBeeSize(int size) {
    this.beeSize = size;
    return this;
  }
