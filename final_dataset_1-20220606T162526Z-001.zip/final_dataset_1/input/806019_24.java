@Override
    public Double getDouble()
    {
        return value;
    }
