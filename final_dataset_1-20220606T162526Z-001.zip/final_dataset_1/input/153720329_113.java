public static String unifySlash(String s) {
        return trimSeparator(s, "\\", "/");
    }
