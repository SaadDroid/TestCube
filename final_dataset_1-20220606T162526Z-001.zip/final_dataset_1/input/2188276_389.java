public String getUser() {
		return user;
	}
