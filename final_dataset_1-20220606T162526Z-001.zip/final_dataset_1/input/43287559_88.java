VerificationErrorCode getErrorCode() {
        return VerificationErrorCode.GEN_04;
    }
