public void run() {
        while (!halted) {
            step();
        }
    }
