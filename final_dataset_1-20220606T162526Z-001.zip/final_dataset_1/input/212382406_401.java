@Override
  public void insertNewDatanode(UUID datanodeID, Set<ContainerID> containerIDs)
      throws SCMException {
    super.insertNewDatanode(datanodeID, containerIDs);
  }
