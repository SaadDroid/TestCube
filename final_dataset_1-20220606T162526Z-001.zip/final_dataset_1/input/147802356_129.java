public boolean isStoreAvailable() {
    return combinedChainDataClient.isStoreAvailable();
  }
