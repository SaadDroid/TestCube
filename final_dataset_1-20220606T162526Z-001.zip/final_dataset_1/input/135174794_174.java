@Override
  public String getNumericPart() {
    return numericPart;
  }
