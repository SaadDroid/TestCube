public ParticipatingExperiment participate() {
        return sixpack.participate(baseExperiment);
    }
