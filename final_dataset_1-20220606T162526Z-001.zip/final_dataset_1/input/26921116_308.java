@Override
    public double mean() {
        return 1 / lambda;
    }
