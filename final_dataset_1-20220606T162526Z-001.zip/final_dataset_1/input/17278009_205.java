public Configuration deepCopy() {
        return deepCopy(true);
    }
