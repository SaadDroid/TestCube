public boolean fire() {
        return this.fire(null);
    }
