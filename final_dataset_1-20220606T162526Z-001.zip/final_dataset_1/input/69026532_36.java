@Override
    public String toString()
    {
        return "EMail{" +
                "id=" + getId() +
                ", address='" + address + '\'' +
                '}';
    }
