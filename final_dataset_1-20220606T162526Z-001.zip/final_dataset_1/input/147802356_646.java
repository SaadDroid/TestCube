public UInt64 decrement() {
    return minus(1);
  }
