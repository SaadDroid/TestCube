public void setReReading(final boolean reReading) {
        mIsReReading = reReading;
    }
