public abstract void set( int i, double val ) throws JWaveException;
