@Override
    public StatusType getStatusInfo() {
        return status;
    }
