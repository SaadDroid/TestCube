@Override
  public Map<String, Metric> getMetrics() {
    return this.innerMetricContext.getMetrics();
  }
