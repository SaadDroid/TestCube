public double[] getVolatility() {
    return _volatility;
  }
