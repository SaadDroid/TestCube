public boolean containsEntry(String queryTerm, String id) {
        return geneIdsByQueryTerm.containsEntry(queryTerm, id);
    }
