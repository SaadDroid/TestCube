public static CharsetPreference wildcard() {
		return new CharsetPreference("*",MAX_WEIGHT);
	}
