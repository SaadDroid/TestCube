public MethodDescriptor.MethodType getType() {
    return method.getType();
  }
