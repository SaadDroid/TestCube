public JsonValue getPatchSuccessDetail(PatchRequest request, ResourceResponse response) {
        return null;
    }
