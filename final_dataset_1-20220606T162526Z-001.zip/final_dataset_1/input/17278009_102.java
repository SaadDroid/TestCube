public long getMaxTime() {
        return maxTime.getAndSet(0);
    }
