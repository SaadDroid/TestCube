@Override
  public String getName() {
    return this.name;
  }
