public static MediaRangeSyntax preferredSyntax() {
		return SYNTAX.get();
	}
