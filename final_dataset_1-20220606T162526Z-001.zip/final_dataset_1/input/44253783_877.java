String wipSuffix() {
    return getWipSuffix() != null ? getWipSuffix() : DEFAULT_WIP_SUFFIX;
  }
