public static int random(double[] prob) {
        int[] ans = random(prob, 1);
        return ans[0];
    }
