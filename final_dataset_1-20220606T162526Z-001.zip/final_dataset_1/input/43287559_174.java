public HashAlgorithm getAggregationAlgorithm() {
        return aggrAlgorithm;
    }
