@Override
    public boolean isRollbackOnly() {
        return rollbackOnly;
    }
