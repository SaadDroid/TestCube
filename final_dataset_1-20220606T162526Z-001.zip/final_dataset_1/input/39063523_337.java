public void populate(final InventoryViewModel inventoryViewModel, String queryKeyWord) {
        setListener(inventoryViewModel);
        inflateData(inventoryViewModel, queryKeyWord);
    }
