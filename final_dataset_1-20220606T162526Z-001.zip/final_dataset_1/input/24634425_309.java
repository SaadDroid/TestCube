public static String objectVMToXML(VM vm) {
		return toXML(VM.class, vm);
	}
