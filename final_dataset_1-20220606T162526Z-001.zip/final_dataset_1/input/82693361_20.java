public void delete() {
        uiUpdates.add(new RemoveBaseEntity(imageView));
    }
