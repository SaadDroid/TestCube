public static Optional<ExitHandler> exitHandler() {
        return Optional.ofNullable(exitHandler);
    }
