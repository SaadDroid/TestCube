public boolean hasReflect() {
    return getRecordType() == AvroRecordType.REFLECT;
  }
