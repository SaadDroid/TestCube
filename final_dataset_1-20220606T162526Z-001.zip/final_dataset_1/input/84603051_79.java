public static Executor fallbackExecutor() {
        return FALLBACK_EXECUTOR;
    }
