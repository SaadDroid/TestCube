public static String getDestSstsPath(String dbPrefix) {
        return String.format("%s/ssts", dbPrefix);
    }
