public JsonValue toJson(Map<String, Set<String>> attributeValuePairs) {
        return toJson(null, attributeValuePairs);
    }
