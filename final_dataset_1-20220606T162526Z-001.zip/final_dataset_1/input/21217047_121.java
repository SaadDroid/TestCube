@Override
    public Iterator<E> structuralIterator() {
        return delegateCollection.iterator();
    }
