public HashAllotRule() {
        this(new int[]{0});
    }
