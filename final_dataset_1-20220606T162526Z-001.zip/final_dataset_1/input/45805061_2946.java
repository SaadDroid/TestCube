public HestonCharacteristicExponent withKappa(final double kappa) {
    return new HestonCharacteristicExponent(kappa, _theta, _vol0, _omega, _rho);
  }
