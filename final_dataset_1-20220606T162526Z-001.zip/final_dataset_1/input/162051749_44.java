public ArgumentBuilder newArgs() {
        return new ArgumentBuilder(query, placeholders);
    }
