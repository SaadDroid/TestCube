public IsJson(Matcher<? super ReadContext> jsonMatcher) {
        this.jsonMatcher = jsonMatcher;
    }
