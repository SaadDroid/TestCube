@Deprecated
    public OkCancelDialog newOkCancelDialog(String title, Object pmo, Handler okHandler) {
        return newOkCancelDialog(title, okHandler, pmo);
    }
