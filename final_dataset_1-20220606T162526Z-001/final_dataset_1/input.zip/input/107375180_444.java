@Override
    public String getCaption(Object o) {
        return getName(o) + " [" + getId(o) + "]";
    }
