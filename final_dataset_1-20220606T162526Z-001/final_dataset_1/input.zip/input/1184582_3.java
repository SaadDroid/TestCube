public Map<String, DeclaredType> getTypes() {
        return types;
    }
