public String getPluginName() {
        return pluginName;
    }
