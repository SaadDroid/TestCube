@SuppressWarnings("deprecation")
    public com.vaadin.v7.ui.Table createTable() {
        return (com.vaadin.v7.ui.Table)CONTAINER_COMPONENT_FACTORY.createContainerComponent(containerPmo,
                                                                                            bindingContext);
    }
