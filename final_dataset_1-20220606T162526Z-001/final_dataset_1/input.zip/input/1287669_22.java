public static String toString(Object o) {
        if (null == o) {
            return null;
        }
        return o.toString();
    }
