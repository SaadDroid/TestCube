void exec() {
    new String(); // do nothing but be measured by jacoco
  }
