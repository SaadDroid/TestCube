@Override
    public <Y> Join<T, Y> join(final SingularAttribute<? super T, Y> attribute) {
        throw new UnsupportedOperationException();
    }
