public Matrix transpose() {
        return Matrix.transpose(this);
    }
