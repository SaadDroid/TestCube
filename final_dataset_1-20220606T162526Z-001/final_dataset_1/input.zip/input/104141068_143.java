@Override
    public <T> T getReference(final Class<T> entityClass, final Object primaryKey) {
        throw new UnsupportedOperationException();
    }
