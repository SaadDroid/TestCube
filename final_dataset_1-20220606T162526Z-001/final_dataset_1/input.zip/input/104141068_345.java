@Override
    public <C, R> SimpleCase<C, R> selectCase(final Expression<? extends C> expression) {
        throw new UnsupportedOperationException();
    }
