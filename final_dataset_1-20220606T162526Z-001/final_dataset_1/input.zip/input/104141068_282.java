@Override
    public Expression<Number> quot(final Expression<? extends Number> x, final Expression<? extends Number> y) {
        throw new UnsupportedOperationException();
    }
