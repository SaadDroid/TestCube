@Override
    public Iterator<E> iterator() {
        return getData().iterator();
    }
