public void setUsername(String name) throws UsernameTooLongException {
        this.username = name;
    }
