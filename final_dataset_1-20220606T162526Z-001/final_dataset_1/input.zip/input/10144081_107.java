@Override
    public Short getRandomValue() {
        return (short) nextDouble(min, max);
    }
