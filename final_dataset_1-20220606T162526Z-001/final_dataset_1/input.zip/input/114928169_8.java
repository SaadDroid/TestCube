public void setUniqueKey(String uniqueKey) {
		this.uniqueKey = uniqueKey;
	}
