@Override
    public <K, V> MapAttribute<T, K, V> getDeclaredMap(final String name, final Class<K> keyType, final Class<V> valueType) {
        throw new UnsupportedOperationException();
    }
