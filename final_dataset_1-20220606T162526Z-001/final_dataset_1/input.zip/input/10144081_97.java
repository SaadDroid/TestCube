public static LocalDateTimeRangeRandomizer aNewLocalDateTimeRangeRandomizer(final LocalDateTime min, final LocalDateTime max) {
        return new LocalDateTimeRangeRandomizer(min, max);
    }
