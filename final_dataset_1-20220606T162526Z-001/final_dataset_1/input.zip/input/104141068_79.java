@Override
    public Set<Entry<K, V>> entrySet() {
        return delegate.entrySet();
    }
