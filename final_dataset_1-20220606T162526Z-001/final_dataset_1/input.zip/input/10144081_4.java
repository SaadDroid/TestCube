public static boolean isInterface(final Class<?> type) {
        return type.isInterface();
    }
