@GET
    @Path("/")
    public static String hello() {
        return "Hello world!";
    }
