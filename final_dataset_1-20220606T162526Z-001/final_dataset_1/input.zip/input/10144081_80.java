public static OffsetTimeRangeRandomizer aNewOffsetTimeRangeRandomizer(final OffsetTime min, final OffsetTime max) {
        return new OffsetTimeRangeRandomizer(min, max);
    }
