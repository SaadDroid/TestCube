@Override
    public <E> ListAttribute<T, E> getDeclaredList(final String name, final Class<E> elementType) {
        throw new UnsupportedOperationException();
    }
