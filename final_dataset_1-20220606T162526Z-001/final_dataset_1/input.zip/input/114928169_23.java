public MsTeamsNotificationContentConfig getContent() {
        return content;
    }
