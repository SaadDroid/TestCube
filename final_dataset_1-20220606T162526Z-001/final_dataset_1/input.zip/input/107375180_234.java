public String getEnabledProperty(String property) {
        return getCombinedPropertyName(property, ENABLED_PROPERTY_SUFFIX);
    }
