@Override
    public Iterable<Category> findAll() {
        return categoryRepository.findAll();
    }
