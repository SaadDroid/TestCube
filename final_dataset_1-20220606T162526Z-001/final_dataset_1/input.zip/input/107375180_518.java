@CheckForNull
    @Override
    public T getParent(Object itemId) {
        return parents.get(itemId);
    }
