@Override
    public boolean hasVersionAttribute() {
        throw new UnsupportedOperationException();
    }
