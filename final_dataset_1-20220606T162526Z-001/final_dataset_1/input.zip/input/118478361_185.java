@Override
    public void warn(String charSequence) {
    }
