public boolean eval(ManifestFile manifest) {
    return visitor().eval(manifest);
  }
