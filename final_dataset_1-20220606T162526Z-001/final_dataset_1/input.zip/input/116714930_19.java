public Consumer<K, V> getConsumer() {
        return consumer;
    }
