public double getFailThreshold() {
        return failThreshold;
    }
