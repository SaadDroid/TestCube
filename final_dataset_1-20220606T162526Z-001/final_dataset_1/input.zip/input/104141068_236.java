@Override
    public Expression<Long> count(final Expression<?> x) {
        throw new UnsupportedOperationException();
    }
