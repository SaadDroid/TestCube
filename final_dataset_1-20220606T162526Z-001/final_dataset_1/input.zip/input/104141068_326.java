@Override
    public Expression<String> trim(final Expression<String> x) {
        throw new UnsupportedOperationException();
    }
