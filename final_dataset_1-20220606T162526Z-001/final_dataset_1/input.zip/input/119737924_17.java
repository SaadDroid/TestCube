public void add(Task task) {
        tasks.add(task);
    }
