@Override
    public <Y> SingularAttribute<T, Y> getDeclaredVersion(final Class<Y> type) {
        throw new UnsupportedOperationException();
    }
