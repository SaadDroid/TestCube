public int foo(  int n){
    if (n > 0) {
      n--;
    }
 else {
      n++;
    }
    return n;
  }
