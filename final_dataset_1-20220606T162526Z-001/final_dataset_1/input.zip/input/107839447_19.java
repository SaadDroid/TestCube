public Matrix minusTo(@NonNull Matrix matrix) {
        checkNotNull(matrix);

        return Matrix.minusTo(this, matrix);
    }
