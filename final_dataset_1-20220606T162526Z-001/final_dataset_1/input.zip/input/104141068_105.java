@Override
    public ClassLoader getNewTempClassLoader() {
        throw new UnsupportedOperationException();
    }
