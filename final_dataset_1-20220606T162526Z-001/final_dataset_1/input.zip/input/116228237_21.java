public String getMessage() {
        return message;
    }
