@Override
    public <T> T unwrap(final Class<T> cls) {
        throw new UnsupportedOperationException();
    }
