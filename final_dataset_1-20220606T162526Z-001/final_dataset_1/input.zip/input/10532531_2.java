@Override
    public String toString() {
        return "VERSION_" + getMajor() + "_" + getMinor() + "_" + getPatch();
    }
