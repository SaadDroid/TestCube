public static Configuration getBaseMRConfiguration(Configuration conf) {
    return getBaseJobConf(conf);
  }
