@Override
    public <T> ParameterExpression<T> parameter(final Class<T> paramClass) {
        throw new UnsupportedOperationException();
    }
