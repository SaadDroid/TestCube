public List<Sort> asList() {
        return sorts;
    }
