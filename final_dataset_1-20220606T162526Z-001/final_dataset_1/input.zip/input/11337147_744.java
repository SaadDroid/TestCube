@Override
    public String defineDefaultSearchOrder() {
        return ApplicationPageItem.ATTRIBUTE_TOKEN;
    }
