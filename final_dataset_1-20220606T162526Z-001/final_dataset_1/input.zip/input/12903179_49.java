public ReadOnlyBooleanProperty validProperty() {
		return valid;
	}
