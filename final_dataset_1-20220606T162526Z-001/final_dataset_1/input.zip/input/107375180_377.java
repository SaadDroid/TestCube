protected AvailableValuesType getAvailableValuesType() {
        return availableValuesType;
    }
