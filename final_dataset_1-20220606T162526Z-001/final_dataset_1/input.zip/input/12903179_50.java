public Command getRemoveCommand() {
		return removeCommand;
	}
