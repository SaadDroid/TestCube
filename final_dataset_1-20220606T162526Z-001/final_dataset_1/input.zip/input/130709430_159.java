Log.in synthesizeLogIn(Log log) {
        return synthesizeAnnotation(getAnnotationAttributes(log), Log.in.class, null);
    }
