public V getPropertyValue(T boundObject) {
        return readMethod.readValue(boundObject);
    }
