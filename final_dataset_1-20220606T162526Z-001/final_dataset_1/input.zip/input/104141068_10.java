@GET
    public static String hello() {
        return "Hello world!";
    }
