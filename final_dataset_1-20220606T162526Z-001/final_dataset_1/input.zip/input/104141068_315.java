@Override
    public Predicate notLike(final Expression<String> x, final Expression<String> pattern) {
        throw new UnsupportedOperationException();
    }
