public Locale getCurrentLocale() {
        return LocaleUtils.getUserLocale(request);
    }
