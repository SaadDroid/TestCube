public String getAvailableValuesProperty(String property) {
        return getCombinedPropertyName(property, AVAILABLE_VALUES_PROPERTY_SUFFIX);
    }
