public void setContext(final Context context) {
        this.context = context;
    }
