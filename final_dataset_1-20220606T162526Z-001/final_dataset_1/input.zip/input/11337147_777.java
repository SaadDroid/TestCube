@Override
    public String defineDefaultSearchOrder() {
        return ProcessInstanceCriterion.CREATION_DATE_DESC.name();
    }
