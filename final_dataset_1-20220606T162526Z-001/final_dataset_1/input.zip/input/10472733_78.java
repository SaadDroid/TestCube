public AvailableForms getAvailableFormByTags(List<String> tagsUuid) throws FormFetchException {
        return getAvailableFormByTags(tagsUuid, false);
    }
