@Override
    public BigDecimal minute(OffsetTime time) {
        return feelLib.minute(time);
    }
