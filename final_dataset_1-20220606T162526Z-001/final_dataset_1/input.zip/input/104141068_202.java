@Override
    public Attribute<T, ?> getDeclaredAttribute(final String name) {
        throw new UnsupportedOperationException();
    }
