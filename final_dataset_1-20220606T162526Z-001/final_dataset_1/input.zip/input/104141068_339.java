@Override
    public Expression<Time> currentTime() {
        throw new UnsupportedOperationException();
    }
