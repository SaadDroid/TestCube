@Override
    public Map<String, Object> getProperties() {
        throw new UnsupportedOperationException();
    }
