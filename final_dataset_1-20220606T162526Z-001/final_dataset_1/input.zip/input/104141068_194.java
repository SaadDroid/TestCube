@Override
    public <E> SetAttribute<? super T, E> getSet(final String name, final Class<E> elementType) {
        throw new UnsupportedOperationException();
    }
